import React, { Component } from "react";

import Panel from "../components/containers/panel";
import ViewStack, { Viewstack } from "../components/containers/viewstack";
import Login from "./../views/login";
import Tabs from "../components/containers/tabs";
import "./container-app.css";

export default class ContainerApp extends Component {
  state = {
    currentViewIndex: 0
  };

  goPre = () => {
    if (this.state.currentViewIndex > 0) {
      this.setState({
        currentViewIndex: this.state.currentViewIndex - 1
      });
    }
  };

  goNext = () => {
    this.setState({
      currentViewIndex: Math.min(this.state.currentViewIndex + 1, 3)
    });
  };

  gotoPage = () => {
    let pageNo = Number(document.getElementById("pageNum").value);
    this.setState({
      currentViewIndex: pageNo
    });
  };
  render() {
    return (
      <div>
        <input id="userName" />
        <Panel tittle="Using View stack Comp">
          <Tabs>
            <Panel title="Login View">
              <Login />
            </Panel>
            <Panel title="Register View" />
            <Panel>
              <h1>3rd child</h1>
            </Panel>
            <Panel title="Last child">4th chidl</Panel>
          </Tabs>

          <hr />

          <Tabs
            className="my-custom-tabs"
            tabButtonClassName="my-custom-tab-button"
            onChange={this.onTabChange}
            defaultSelectedIndex={0}
          >
            <Panel title="Login View">
              <Login />
            </Panel>
            <Panel title="Register View" />
            <Panel disabled={true}>
              <h1>3rd child</h1>
            </Panel>
            <Panel title="Last child">4th chidl</Panel>
          </Tabs>
        </Panel>
      </div>
    );
  }

  onTabChange = (e, newIndex, oldIndex) => {
    if(newIndex === 1) {
      e.preventDefault();
      console.log({newIndex, oldIndex})
    }
    
  }
}

/**
 * 
 * <Viewstack selectedIndex={this.state.currentViewIndex}>
           <Login />
            <div>
              <h1>this is view 2</h1>
              <button onClick={this.goPre}>Previous</button>
              <button onClick={this.goNext}>Next</button>
            </div>
            <div>
              <h1>this is view 3</h1>
              <button onClick={this.goPre}>Previous</button>
              <button onClick={this.goNext}>Next</button>
            </div>
            <div>
              <h1>this is view 4</h1>
              <button onClick={this.goPre}>Previous</button>
              <button onClick={this.goNext}>Next</button>
            </div>
          </Viewstack>
          <input id="pageNum" /> <button onClick={this.gotoPage}>Goto</button>
 */
