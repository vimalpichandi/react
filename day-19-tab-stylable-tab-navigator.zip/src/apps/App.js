import React, { Component } from "react";
import PropTypes from "prop-types";
import Panel from "./components/containers/panel";
import List from "./components/list";
import MyTimer from "./components/my-timer";
import Clock from "./components/clock";
import "./App.css";
/* 
export function App() {
  return <div>this is react app</div>
}
 */
/*
export const App = () => {
  return <div>this is react app</div>;
};
*/

class CountDownTimer extends Component {
  constructor(props) {
    super(props);
    this.countDown = props.startValue;
    this.notifyOnComplete = props.notifyOnComplete;
    this.timer = setInterval(this.updateTime, 999);
  }

  updateTime = () => {
    this.countDown--;
    if (this.countDown <= 0) {
      clearInterval(this.timer);

      if (this.notifyOnComplete) {
        this.props.onTimeUp("hi");
      }
    }
    this.forceUpdate();
  };

  render() {
    return <div>{this.countDown}</div>;
  }
}

CountDownTimer.propTypes = {
  startValue: PropTypes.number /** */,
  notifyOnComplete: PropTypes.bool.isRequired,
  items: PropTypes.arrayOf(
    PropTypes.shape({
      dob: PropTypes.number,
      name: PropTypes.string.isRequired
    })
  ),
  someThing: PropTypes.oneOf([PropTypes.object, PropTypes.bool])
};

CountDownTimer.defaultProps = {
  startValue: 10,
  notifyOnComplete: true
};

const item = (name, gender, age) => ({
  name,
  gender,
  age
});

export class App extends Component {
  onFinish = msg => {
    alert("Count down is finished : " + msg);
  };

  state = {
    showClock: true
  };

  onToggle = e => {
    this.setState({
      showClock: !this.state.showClock
    });
  };

  onUserSelect = item => {
    console.log("selected user: ", item);
  }

  onRemoveItem = e => {
    e.stopPropagation();
  }
  
  renderItemWithButton = item => {
    return <div><span>{item}</span><button onClick={this.onRemoveItem}>-</button></div>
  }

  render() {
    let org = "Hope Tutors Inc";
    return (
      <div>
        <Header co={org} />
        <Panel title="Clock - component lifecycle methods example">
          {this.state.showClock ? <Clock /> : null}
          <button onClick={this.onToggle}>Toggle Clock Visibility</button>
        </Panel>
        <Panel title="Count Down Timer">
          <section>this is react app section</section>
          <CountDownTimer
            onTimeUp={this.onFinish}
            startValue={4}
            notifyOnComplete={!true}
          />
        </Panel>
        <Panel title="Simple List">
          <List items={["Gokul", "Vimal", "Vinoth"]}
          itemRenderer={this.renderItemWithButton} />
          <List items={[1, 2, 39, 0, 657]} />
          <List
            items={[
              item("Gokul", "m", 33),
              item("Vimal", "m", 32),
              item("Vinoth", "m", 44),
              item("Women", "f", 46)
            ]}
            uiField="name"
          />
          <List
            onSelect={this.onUserSelect}
            className="horizontal-list"
            items={[
              item("Gokul", "m", 33),
              item("Vimal", "m", 32),
              item("Vinoth", "m", 44),
              item("Women", "f", 46)
            ]}
            itemRenderer={this.studentRederer}
          />
        </Panel>
        {/*
        <Panel title="Timer with state">
          <MyTimer startValue={10} />
        </Panel>
        */}
        <Footer co={org} />
      </div>
    );
  }

  studentRederer = (item) => {
    return <div>{item.gender==="m" ? "👨" : "👩"} - {item.name}</div>
  }
}

class Header extends Component {
  render() {
    return (
      <header>
        <h1>{this.props.co}</h1>
        --{this.props.children}--
      </header>
    );
  }
}

const Footer = props => {
  return (
    <footer>
      <CopyRights year={props.year} org={props.co} />
    </footer>
  );
};
const CopyRights = params => {
  return (
    <span>
      Copyright &copy; {params.org} {params.year}. All Rights Reserved.
    </span>
  );
};

CopyRights.defaultProps = {
  org: "Hope Tuters Inc",
  year: 2018
};

export default App;
