import React, { Component } from "react";

import "./tabs.css";

export default class Tabs extends Component {
  state = {
    selectedIndex: this.props.defaultSelectedIndex || 0
  };
  renderView = (child, index) => {
    let cn = "tabs-view";
    if (this.state.selectedIndex === index) {
      cn += " active";
    }
    return (
      <div key={index} className={cn}>
        {child}
      </div>
    );
  };

  renderButton = (view, index) => {
    let title = view.props.title || `Tab ${index + 1}`;
    let tabButtonClassName = "tab-button ";
    if (this.props.tabButtonClassName) {
      tabButtonClassName += this.props.tabButtonClassName;
    }
    if (index === this.state.selectedIndex) {
      tabButtonClassName += " active";
    }
    return (
      <button
        disabled={view.props.disabled}
        className={tabButtonClassName}
        onClick={event => {
          if (this.props.onChange) {
            this.props.onChange(event, index, this.state.selectedIndex);
          }
          if (!event.isDefaultPrevented()) {
            this.setState({ selectedIndex: index });
          }
        }}
      >
        {title}
      </button>
    );
  };
  render() {
    let cn = "tabs";
    if (this.props.className) {
      cn += " " + this.props.className;
    }
    return (
      <div className={cn}>
        <header className="tab-button-holder">
          {React.Children.map(this.props.children, this.renderButton)}
        </header>
        <section className="tab-child-holder">
          {React.Children.map(this.props.children, this.renderView)}
        </section>
      </div>
    );
  }
}
