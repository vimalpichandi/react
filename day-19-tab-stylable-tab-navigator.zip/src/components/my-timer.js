import React, { Component } from 'react'

export default class MyTimer extends Component {
    

    constructor(props) {
        super(props);

        this.timerID = setInterval(this.updateCount, 999);
    }

    state = {
        count: this.props.startValue
    } 

    updateCount = () => {
        if(this.state.count > 0) {
            this.setState({
                count: this.state.count - 1
            });
        } else {
            alert("done");

            this.clearTimer();
        }
    }

    clearTimer = () => {
        clearInterval(this.timerID);
    }

    componentWillUnmount() {
        this.clearTimer();
    }

    render() {
        return (
            <div>
                {
                    this.state.count
                }
            </div>
        )
    }
}
