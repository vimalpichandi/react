import React, { Component } from "react";

/**
 * <List items={[1,2,3]} />
 */

import "./list.css";

export default class List extends Component {
  /*
    constructor(props) {
        super(props);

        this.state = {
            items: []
        }
    }
    */

  state = {
    selectedIndex: -1,
  };

  onItemClick = event => {
    let d = event.currentTarget;
    let index = Number(d.dataset.index); // 2

    //this.state.selectedIndex = index; // Dont do this

    this.setState({
      selectedIndex: index
    });

    this.state.selectedIndex=0; // ???

  };

  renderItem = (item, index /*, arr */) => {
    let selectedIndex = this.state.selectedIndex;
    let className = "my-list-item";
    if (selectedIndex === index) {
      className += " active";
    }
    return (
      <div
        key={index}
        className={className}
        data-index={index}
        onClick={this.onItemClick}
      >
          
        {item}
      </div>
    );
  };

  render() {
    let items = this.props.items;
    return <div className="my-list">{items.map(this.renderItem)}</div>;
  }
}
