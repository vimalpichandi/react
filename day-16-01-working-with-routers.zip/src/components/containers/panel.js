import React, { Component } from "react";
import "./panel.css";

export default class Panel extends Component {
  render() {
    return (
      <section className="my-panel">
        <header className="my-panel-header">{this.props.title}</header>
        <section className="my-panel-section">{this.props.children}</section>
      </section>
    );
  }
}
