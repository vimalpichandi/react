import React, { Component } from "react";

import {
  BrowserRouter,
  Route,
  NavLink as Link,
  Switch
} from "react-router-dom";

import "./router-app.css";

export default class RouterApp extends Component {
  render() {
    return (
      <div className="routed-app">
        <BrowserRouter>
          <header className="nav-bar">
            <Link activeClassName="active" to="/" exact>
              Home
            </Link>
            <Link activeClassName="active" to="/users">
              Users
            </Link>
            <Link activeClassName="active" to="/contacts">
              Contacts
            </Link>
          </header>
          <section>
            <Switch>
              <Route
                path="/users/:login/repos/:repo"
                component={UserRepoDetail}
              />
              <Route path="/users/:login/repos" component={UserRepos} />
              <Route path="/users/:login" component={UserDetails} />
              <Route path="/users" component={Users} />
              <Route path="/contacts" component={Contacts} />
              <Route path="/" component={Home} exact />
              <Route component={RouteNotFound} />
            </Switch>
          </section>
        </BrowserRouter>
      </div>
    );
  }
}

const Home = () => {
  return (
    <div className="route">
      <h1>this is home page</h1>
    </div>
  );
};

const Users = () => {
  return (
    <div className="route">
      <h1>this is users page</h1>
    </div>
  );
};

const UserDetails = ({ location, match, history }) => {
  return (
    <div className="route">
      <h1>this is user details page of {match.params.login}</h1>
    </div>
  );
};

const UserRepos = ({ location, match, history }) => {
  return (
    <div className="route">
      <h1>this is repos of the user {match.params.login}</h1>
    </div>
  );
};

const UserRepoDetail = ({ location, match, history }) => {
  return (
    <div className="route">
      <h1>this is repos of the user {match.params.login}</h1>
      <h1>{match.params.repo}</h1>
    </div>
  );
};

const Contacts = () => {
  return (
    <div className="route">
      <h1>this is contacts page</h1>
    </div>
  );
};

const RouteNotFound = () => {
  return (
    <div className="route">
      <h1>404: page not found</h1>
    </div>
  );
};
