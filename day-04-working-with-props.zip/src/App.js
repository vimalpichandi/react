import React, { Component } from "react";
/* 
export function App() {
  return <div>this is react app</div>
}
 */
/*
export const App = () => {
  return <div>this is react app</div>;
};
*/

class CountDownTimer extends Component {

  constructor(props) {
    super(props);
    this.countDown = props.startValue;
    this.timer = setInterval(this.updateTime, 999);
  }

  updateTime = () => {
    this.countDown--;
    if(this.countDown <= 0) {
      clearInterval(this.timer);
      this.props.onTimeUp("hi");
    }
    this.forceUpdate();
  }

  render() {
    return <div>{this.countDown}</div>
  }
}

CountDownTimer.defaultProps = {
  startValue: 10
}

export class App extends Component {

  onFinish = (msg) => {
    alert("Count down is finished : " + msg);
  }

  render() {
    let org = "Hope Tutors Inc";
    return (
      <div>
        <Header co={org} />
        <section>this is react app section</section>
        <CountDownTimer onTimeUp={this.onFinish} startValue={4} />
        <Footer co={org}  />
      </div>
    );
  }
}

class Header extends Component {
  render() {
    return (
      <header>
        <h1>{this.props.co}</h1>
      </header>
    );
  }
}

const Footer = props => {
  return (
    <footer>
      <CopyRights year={props.year} org={props.co} />
    </footer>
  );
};
const CopyRights = params => {
  return (
    <span>
      Copyright &copy; {params.org} {params.year}. All Rights Reserved.
    </span>
  );
};

CopyRights.defaultProps = {
  org: "Hope Tuters Inc",
  year: 2018
};

export default App;
