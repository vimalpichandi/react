import React, { Component } from "react";

import "./list.css";

export class List extends Component {

  constructor(props) {
    super(props);

    //this.onListItemClick = this.onListItemClick.bind(this);

    this.state = {
      selectedIndex: -1
    }
  }

  onListItemClick = (e) => {
   
    let d = e.currentTarget;
    let i = Number(d.dataset.index);
    let si = this.props.items[i];
    this.props.onSelect && this.props.onSelect(si);
    this.setState({
      selectedIndex: i
    });
  }

  renderItem = (item, i) => {
    let ui = "";

    let cn = "my-list-item";

    if(this.state.selectedIndex === i) {
      cn += " active";
    }

    if (this.props.itemRenderer) {
      ui = this.props.itemRenderer(item);
    } else if (typeof item === "string" || typeof item === "number") {
      ui = item;
    } else {
      //ui = JSON.stringify(item);
      //ui = item.name;
      //ui = item["name"];
      let uiField = this.props.uiField; //"name";
      ui = item[uiField];
    }
    return (
      <div className={cn} key={i} onClick={this.onListItemClick} data-index={i}>
        {ui}
      </div>
    );
  };

  render() {
    let { items = [] } = this.props;
    //let items = this.props.items;

    console.log(items.map(this.renderItem));

    if (!items || items.length === 0) {
      return (
        <div className="my-list">
          <div>No Data supplied</div>
        </div>
      );
    }

    return <div className="my-list">{items.map(this.renderItem)}</div>;
  }
}

List.defaultProps = {
  uiField: "label"
};

export default List;
