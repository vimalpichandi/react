import React, { Component } from 'react'

import "./clock.css";

export default class Clock extends Component {

    state = {
        hh: 0,
        mm: 0,
        ss: 0,
        shift: "",
    }

    componentDidMount() {
        this.timerID = setInterval(this.updateTime, 200);
    }

    componentWillUnmount() {
        clearInterval(this.timerID);
        console.log("clearing the timer..")
    }

    updateTime = () => {
        let d = new Date();
        this.setState({
            hh: d.getHours(),
            mm: d.getMinutes(),
            ss: d.getSeconds(),
            shift: d.getHours() > 12 ? "PM" : "AM"
        });

        console.log('updating time..ss: %d', d.getSeconds());
    }

    render() {

        let {hh, mm, ss, shift} = this.state;

        return (
            <div className="clock">
                <span>{hh}</span> : 
                <span>{mm}</span> : 
                <span>{ss}</span> 
                <span>{shift}</span>
            </div>
        )
    }
}
