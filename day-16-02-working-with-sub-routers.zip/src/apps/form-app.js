import React, { Component } from "react";
import Login from "./views/login";
import List from "./components/list";

export default class FormApp extends Component {
  state = {
    products: [],
    status: ""
  };

  componentDidMount() {
    this.getProducts(1, 10);
  }

  getProducts = (page, size) => {
    this.setState({ status: "Loading products...!" });
    let url = `./products?page=${page}&size=${size}`;
    let config = {
      method: "POST",
      body: JSON.stringify({page, size})
    }
    fetch(url, config)
      .then(this.onResponse)
      .then(this.onResult)
      .catch(this.onError);
  };

  onError = error => {
    console.log(error);
    this.setState({ status: "Failed to load products...!" });
  };

  onResult = result => {
    if (result.status) {
      console.log(result.data);
      this.setState({ products: result.data });
      this.setState({ status: "" });
    } else {
      //
      this.setState({ status: "failed to load products" });
    }
  };

  onResponse = response => {
    return response.json();
  };
  render() {
    return (
      <div>
        <Login />
        {this.state.status ? (
          <span>{this.state.status}</span>
        ) : (
          <List
            items={this.state.products}
            itemRenderer={this.productRederere}
          />
        )}
      </div>
    );
  }

  productRederere = product => {
    return (
      <div key={product.id}>
        <span title={product.description}>{product.name}</span>
      </div>
    );
  };
}
