import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import RouterApp from './apps/router-app';

ReactDOM.render(<RouterApp />, document.getElementById('my-app'));