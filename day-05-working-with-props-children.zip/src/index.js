import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import {App as Hope} from './App';

ReactDOM.render(<Hope />, document.getElementById('my-app'));