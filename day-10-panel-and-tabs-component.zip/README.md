how to create a react project
functional component
class component
props
applying style
array.map
states