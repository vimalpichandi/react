import React, { Component } from "react";

import "./tabs.css";

export default class Tabs extends Component {
  state = {
    selectedChildIndex: 0
  };

  renderChildLink = (child, index) => {
    return (
      <button
        key={index}
        onClick={() => {
          this.setState({
            selectedChildIndex: index
          });
        }}
      >
        Tab {index + 1}
      </button>
    );
  };

  renderChild = (child, index) => {
    let cn = "tabs-child";
    if (index === this.state.selectedChildIndex) {
      cn += " active";
    }
    return (
      <div className={cn} key={index}>
        {child}
      </div>
    );
  };
  render() {
    return (
      <div className="tabs">
        <header className="tabs-header">
          {React.Children.map(this.props.children, this.renderChildLink)}
        </header>
        <section className="tabs-body">
          {React.Children.map(this.props.children, this.renderChild)}
        </section>
      </div>
    );
  }
}
