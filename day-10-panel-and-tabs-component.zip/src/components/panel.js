import React, { Component } from "react";
import "./panel.css";
export default class Panel extends Component {
  render() {
    return (
      <div className="panel">
        <header className="panel-header">
          <span className="panel-header-icon">☀</span>
          <h1 className="panel-header-title">{this.props.title}</h1>
        </header>
        <section className="panel-body">{this.props.children}</section>
        <footer className="panel-footer">
            this is panel footer
        </footer>
      </div>
    );
  }
}
