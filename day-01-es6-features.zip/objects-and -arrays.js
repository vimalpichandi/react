var aa = new Array(6, 33, 355);

aa = [6, 33, 355, "jhghjh", { w: 89 }];

var bb = [...aa];
var [x, y, z] = aa;


function doSomething({ p1, p2, p3 }) {

}


doSomething(s);


function toUC(item) {
    return item.toUpperCase();
}

let uc = (item, i, arr) => { return item.toUpperCase() }

let names = ["hello", "bob", "smith"];
let un = names.map(toUC);
console.log(un, names, names.map(uc));


function sumOf(a, b) {
    a = a || 0;
    b = b || 0;

    return a + b;
}

function sumOf1(a=0, b=0) {

    return a + b;
}


sumOf(1,2);
sumOf1(undefined, 2);

var x;
let l1 =98;
const PI = 3.1427;

x = 8687;

if(true) {
    var t1 = 87678;
    let t3 = "898"
}

function sumx (a, b, ...params) {
    let l = params.length;
    let s = a+b;
    for(let i=0; i<l; i++) {
        s+= params[i];
    }
    return s;
}

let name = "jagan";
let surName = "Mr";
let job = "trainer";

let message = `${surName} ${name} is a ${job}`;

let emp = {
    name: "jagan",
    job: "trainer"
}

function toStr() {
    return `${this.name} is a ${this.job}`;
}
