/* function Employee(id, fname, lname) {
    this.id = id;
    this.fname = fname;
    this.lname = lname;

    
}

Employee.prototype.fullName = function() {
    return this.fname + " " + this.lname;
}


let e = new Employee(1, "jaga", "kjhkj");
e.fullName();
 */
class Person {

    constructor(id, fn, ln) {
        this.fname = fn;
        this.lname = ln;
        this.id = id;

        Person.instanceCount++;
    }

    fullName() {
        return this.fname + " " + this.lname;
    }
}

Person.instanceCount = 0;

class Employee extends Person {

}

class Student extends Person {
    constructor(course, id, fn, ln) {
        super(id, fn, ln);
        this.course = course;
        
    }

    fullName() {
        return "Mr. " + super.fullName();
    }
}

let s = new Student("reactJS", 1, "gokul", "k");

console.log(s.fullName(), s.course, Person.instanceCount);


