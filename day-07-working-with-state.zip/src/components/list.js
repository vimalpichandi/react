import React, { Component } from "react";

/**
 * <List items={[1,2,3]} />
 */

import "./list.css";

export default class List extends Component {
  
    /* constructor(props) {
        super(props);

        let tempState = {
            items: []
        }

        //

        //

        ///

        //tempState.kjagfhka =98798;
        this.state = tempState;
    } */
    
    

  state = {
    items: [],
    selectedIndex: -1,
  };

  onStateUpdate = () => {
    // let x = this.state.selectedIndex
    // do something
  }

  onItemClick = event => {
    let d = event.currentTarget;
    let index = Number(d.dataset.index); // 2

    //this.state.selectedIndex = index; // Dont do this

    let newData = {
      selectedIndex: index
    };
    // option 1
    this.setState(newData);

    // option 2
    this.setState(tempState=>{
      // let si = tempState.selectedIndex;
      return {};
    });

    // option 3
    this.setState({}, this.onStateUpdate);

    // option 4
    this.setState(p=>{}, this.onStateUpdate);

    // var si = this.state.selectedIndex; // ???

  };

  renderItem = (item, index /*, arr */) => {
    let selectedIndex = this.state.selectedIndex;
    let className = "my-list-item";
    if (selectedIndex === index) {
      className += " active";
    }
    return (
      <div
        key={index}
        className={className}
        data-index={index}
        onClick={this.onItemClick}
      >
          
        {item}
      </div>
    );
  };

  render() {
    let items = this.props.items;
    return <div className="my-list">{items.map(this.renderItem)}</div>;
  }
}
