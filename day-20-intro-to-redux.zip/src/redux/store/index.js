import {createStore } from "redux";


const rootReducer = (state={}, action) => {
    switch(action.type) {
        case "login": return {userName: action.payload.userName, sessionId: action.payload.sessionId};
        case "logout": return {};
        default: return state;
    }
}


export const store = createStore(rootReducer)