import React, { Component } from "react";
import {store} from "./../redux/store";

export default class Login extends Component {
  state = {
    userName: "",
    password: "",
    userNameError: ""
  };

  loginClick = e => {
    // make ajax call.
    store.dispatch({type:"login", payload: {userName: this.state.userName, sessionId: "hjhg7-34424-23423-zxx-342"}})
  }

  onInputChange = e => {
    this.setState({
      [e.target.id]: e.target.value.toUpperCase()
    });
  };

  onInputBlur = e => {
    if (e.target.id === "userName") {
      if (e.target.value.indexOf(" ") >= 0) {
        this.setState({
          userNameError: "should not have space"
        });
      } else {
        this.setState({
          userNameError: ""
        });
      }
    }
  };

  onRememberMeChange = e => {
    this.setState({
      rememberMe: e.target.checked
    });
  };

  onUserNameFocus = () => {
    this.setState({
      userNameError: ""
    });
  };

  getInputRef = input => {
    this.userNameInput = input;
  }

  componentDidMount() {
    if(this.userNameInput) {
      this.userNameInput.focus();
    } 

    //document.getElementById("userName").value = "new hi"
  }

  componentWillUnmount() {
    this.userNameInput = null;
  }
  render() {
    console.log(this.state);
    return (
      <div>
        <div>
          <h3>Login: Hope Tutors</h3>
        </div>
        <div>
          <label>Username</label>
          <input
            id="userName"
            type="text"
            ref={this.getInputRef}
            placeholder="eg.jagan"
            onChange={this.onInputChange}
            onBlur={this.onInputBlur}
            onFocus={this.onUserNameFocus}
          />
          {this.state.userNameError ? (
            <span className="input-error">{this.state.userNameError}</span>
          ) : null}
        </div>
        <div>
          <label>Password</label>
          <input
            id="password"
            type="password"
            onChange={this.onInputChange}
            placeholder="password"
          />
        </div>
        <div>
          <label>Remember Me</label>
          <input
            onChange={this.onRememberMeChange}
            type="checkbox"
            id="rememberMe"
          />
        </div>
        <div>
          <label>Login As</label>
          <input type="radio" name="loginType" id="cust" />
          <label htmlFor={"cust"}>Customer</label>
          <input type="radio" name="loginType" id="vend" />
          <label htmlFor="vend">Vendor</label>
        </div>
        <div>
          <label>Gender</label>
          <input type="radio" name="gender" />
          <label>MAle</label>
          <input type="radio" name="gender" />
          <label>Femal</label>
        </div>
        <div>
          <button onClick={this.loginClick}>Login</button>
          <button>Reset</button>
        </div>
      </div>
    );
  }
}
