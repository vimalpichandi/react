import React, { Component } from "react";

export class Viewstack extends Component {
  renderView = (view, index) => {
    if (this.props.selectedIndex === index) {
      return (
        <div key={index} className="viewstack-view">
          {view}
        </div>
      );
    } else {
      return null;
    }
  };
  render() {
    return (
      <div className="viewstack">
        {React.Children.map(this.props.children, this.renderView)}
      </div>
    );
  }
}

Viewstack.defaultProps = {
  selectedIndex: 0
};

export default Viewstack;
