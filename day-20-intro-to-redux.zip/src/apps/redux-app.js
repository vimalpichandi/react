import React, { Component } from "react";
import Login from "../views/login";
import { store } from "../redux/store";
import Tabs from "./../components/containers/tabs";

export default class ReduxApp extends Component {
  state = {
    currentView: 0
  };

  componentDidMount() {
    store.subscribe(this.onStoreChange);
  }

  onStoreChange = () => {
    console.log(store);
    if (store.getState().userName) {
      this.setState({ currentView: 1 });
    } else {
      alert("something got changed in store!!!");
    }
  };

  getCurrentView = () => {
    if (this.state.currentView === 0) {
      return <Login title="Login View" />;
    } else {
      return <div title="Welcome">
        You got logged in as {store.getState().userName} !!!
      </div>;
    }
  };

  render() {
    return (
      <div>
        <header>
          <h1>Redux</h1>
        </header>
        {this.getCurrentView()}
      </div>
    );
  }
}
