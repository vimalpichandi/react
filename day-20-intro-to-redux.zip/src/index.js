import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
//import RouterApp as App from './apps/router-app';
//import App from "./apps/container-app";
import App from "./apps/redux-app";

ReactDOM.render(<App />, document.getElementById('my-app'));