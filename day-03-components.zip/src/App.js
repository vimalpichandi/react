import React, { Component } from "react";
/* 
export function App() {
  return <div>this is react app</div>
}
 */
/*
export const App = () => {
  return <div>this is react app</div>;
};
*/

export class App extends Component {
  render() {
    return (
      <div>
        <Header />
        <section>this is react app section</section>
        <Footer />
      </div>
    );
  }
}

const Header = () => {
  return (
    <header>
      <h1>Hope Tutors Inc</h1>
    </header>
  );
};

const CopyRights = () => {
  return (
    <span>Copyright &copy; Hope Tutors Inc. 2019. All Rights Reserved.</span>
  );
};

const Footer = () => {
  return (
    <footer>
      <CopyRights />
    </footer>
  );
};

export default App;
