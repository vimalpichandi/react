import React, { Component } from "react";

import Panel from "../components/containers/panel";
import ViewStack, { Viewstack } from "../components/containers/viewstack";
import Login from "./../views/login"

export default class ContainerApp extends Component {
  state = {
    currentViewIndex: 0
  };

  goPre = () => {
    if (this.state.currentViewIndex > 0) {
      this.setState({
        currentViewIndex: this.state.currentViewIndex - 1
      });
    }
  };

  goNext = () => {
    this.setState({
      currentViewIndex: Math.min(this.state.currentViewIndex + 1, 3)
    });
  };
 
  gotoPage = () => {
      let pageNo = Number(document.getElementById("pageNum").value);
      this.setState({
          currentViewIndex: pageNo
      });
  }
  render() {
    return (
      <div>
        <Panel tittle="Using View stack Comp">
          <Viewstack selectedIndex={this.state.currentViewIndex}>
           <Login />
            <div>
              <h1>this is view 2</h1>
              <button onClick={this.goPre}>Previous</button>
              <button onClick={this.goNext}>Next</button>
            </div>
            <div>
              <h1>this is view 3</h1>
              <button onClick={this.goPre}>Previous</button>
              <button onClick={this.goNext}>Next</button>
            </div>
            <div>
              <h1>this is view 4</h1>
              <button onClick={this.goPre}>Previous</button>
              <button onClick={this.goNext}>Next</button>
            </div>
          </Viewstack>
          <input id="pageNum" /> <button onClick={this.gotoPage}>Goto</button>
        </Panel>
      </div>
    );
  }
}
